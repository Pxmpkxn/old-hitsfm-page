function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

var playing = false;

async function playRadio() {
    if (playing == true) {
        $(".audio-play")[0].className = "audio-play fas fa-play";
        playing = false;
        audio.volume = 0;
    } else {
        $(".audio-play")[0].className = "audio-play fas fa-pause";
        playing = true;
        audio.src = "https://azuracast.djkeiran.co.uk/listen/luna_radio/radio.mp3";
        audio.volume = 0.4;
        audio.play();
        await sleep(500)
    }
}

var audio = $(".matstream-stream")[0];

document.addEventListener('contextmenu',(e)=>{
    e.preventDefault();
  }
  );
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
     return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
     return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) {
     return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
     return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
     return false;
  }
}